<?php
// ============================================================
// FILE: admin/plans.php — REPLACE existing
// ============================================================
require_once '../config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireAdmin();

$errors = []; $editing = null;

// --- Delete ---
if (isset($_GET['delete'])) {
    $did = intval($_GET['delete']);
    $cnt = $conn->query("SELECT COUNT(*) AS c FROM contributions WHERE plan_id=$did")->fetch_assoc()['c'];
    if ($cnt > 0) { setFlash('error','Cannot delete — members have joined this plan.'); }
    else { $conn->query("DELETE FROM plans WHERE id=$did"); setFlash('success','Plan deleted.'); }
    header("Location: plans.php"); exit();
}

// --- Manual status change ---
if (isset($_GET['setstatus'])) {
    $sid    = intval($_GET['plan']);
    $status = $_GET['setstatus'];
    if (in_array($status, ['open','active','completed'])) {
        $conn->query("UPDATE plans SET plan_status='$status' WHERE id=$sid");
        if ($status === 'active') {
            // Recalculate dates so members see their collection dates immediately
            recalculatePlanDates($conn, $sid);
        }
        setFlash('success', 'Plan status changed to ' . ucfirst($status) . '.');
    }
    header("Location: plans.php"); exit();
}

// --- Edit load ---
if (isset($_GET['edit'])) {
    $s = $conn->prepare("SELECT * FROM plans WHERE id=?");
    $s->bind_param("i", intval($_GET['edit'])); $s->execute();
    $editing = $s->get_result()->fetch_assoc(); $s->close();
}

// --- Save ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = trim($_POST['name']        ?? '');
    $desc       = trim($_POST['description'] ?? '');
    $amount     = floatval($_POST['contribution_amount'] ?? 0);
    $freq       = intval($_POST['frequency_days']        ?? 7);
    $total      = intval($_POST['total_participants']    ?? 5);
    $start_date = trim($_POST['plan_start_date'] ?? '') ?: null;
    $is_active  = isset($_POST['is_active']) ? 1 : 0;
    $plan_id    = intval($_POST['plan_id']   ?? 0);

    if (empty($name))  $errors[] = "Plan name is required.";
    if ($amount <= 0)  $errors[] = "Contribution amount must be greater than zero.";
    if ($freq   <= 0)  $errors[] = "Frequency days must be at least 1.";
    if ($total  <= 1)  $errors[] = "A group needs at least 2 participants.";

    if (empty($errors)) {
        if ($plan_id > 0) {
            $s = $conn->prepare(
                "UPDATE plans SET name=?,description=?,contribution_amount=?,
                 frequency_days=?,total_participants=?,plan_start_date=?,is_active=?
                 WHERE id=?"
            );
            $s->bind_param("ssdiiisi", $name,$desc,$amount,$freq,$total,$start_date,$is_active,$plan_id);
            $s->execute(); $s->close();
            recalculatePlanDates($conn, $plan_id);

            // Auto-activate plan if it is full and has a start date
            $filled = getPlanMemberCount($conn, $plan_id);
            if ($start_date && $filled >= $total) {
                $conn->query("UPDATE plans SET plan_status='active' WHERE id=$plan_id AND plan_status='open'");
            }
            setFlash('success', 'Plan updated. Collection dates recalculated.');
        } else {
            $s = $conn->prepare(
                "INSERT INTO plans (name,description,contribution_amount,frequency_days,total_participants,plan_start_date,is_active)
                 VALUES (?,?,?,?,?,?,?)"
            );
            $s->bind_param("ssdiiis", $name,$desc,$amount,$freq,$total,$start_date,$is_active);
            $s->execute(); $s->close();
            setFlash('success', 'Plan created. Members can now join.');
        }
        header("Location: plans.php"); exit();
    }
}

$plans = $conn->query(
    "SELECT p.*,
        (SELECT COUNT(*) FROM contributions c WHERE c.plan_id=p.id AND c.status!='removed') AS slots_filled
     FROM plans p ORDER BY
        FIELD(p.plan_status,'open','active','completed'),
        p.created_at DESC"
)->fetch_all(MYSQLI_ASSOC);

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Manage Plans — <?= SITE_NAME ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.status-flow {
    display: flex;
    align-items: center;
    gap: .35rem;
    font-size: .78rem;
    color: var(--gray-text);
    margin-top: .4rem;
    flex-wrap: wrap;
}
.status-flow__step {
    padding: .2rem .55rem;
    border-radius: 20px;
    font-weight: 600;
    font-size: .7rem;
    text-transform: uppercase;
    letter-spacing: .04em;
}
.status-flow__step--done   { background: #EDF7F1; color: #1E7E4A; }
.status-flow__step--active { background: var(--gold); color: var(--white); }
.status-flow__step--future { background: var(--gray-light); color: var(--gray-text); }
.status-flow__arrow { color: var(--gray-mid); font-size: .9rem; }
</style>
</head>
<body class="inner-page">
<?php include 'admin_nav.php'; ?>
<main class="main-content"><div class="container">

<div class="page-header"><h1>Manage Plans</h1>
  <p>Create plans, set start dates, and control when each group opens and closes.</p>
</div>

<?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] ?>"><p><?= htmlspecialchars($flash['message']) ?></p></div>
<?php endif; ?>

<!-- How plan lifecycle works -->
<div class="admin-info-box" style="margin-bottom:2rem;">
  <strong>Plan Lifecycle:</strong>
  <strong style="color:#4338CA;">Open</strong> — accepting members &nbsp;→&nbsp;
  <strong style="color:var(--gold);">Active</strong> — group full + started, no new members &nbsp;→&nbsp;
  <strong style="color:var(--success);">Completed</strong> — all members have collected.
  A plan auto-activates when full AND a start date is set. You can also change status manually below.
</div>

<div class="admin-two-col">
  <!-- Create / Edit form -->
  <div class="admin-form-panel">
    <h2><?= $editing ? 'Edit Plan' : 'Create New Plan' ?></h2>
    <?php if (!empty($errors)): ?>
      <div class="alert alert-error">
        <?php foreach ($errors as $e): ?><p><?= htmlspecialchars($e) ?></p><?php endforeach; ?>
      </div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="plan_id" value="<?= $editing['id'] ?? 0 ?>">

      <div class="form-group">
        <label>Plan Name</label>
        <input type="text" name="name" placeholder="e.g. Weekly Ajo — 5 People"
               value="<?= htmlspecialchars($_POST['name'] ?? $editing['name'] ?? '') ?>" required>
      </div>

      <div class="form-group">
        <label>Description</label>
        <textarea name="description" rows="2" placeholder="Short description shown to members"><?= htmlspecialchars($_POST['description'] ?? $editing['description'] ?? '') ?></textarea>
      </div>

      <div class="form-group">
        <label>Contribution Amount (₦) per person</label>
        <input type="number" name="contribution_amount" step="0.01" min="1"
               value="<?= htmlspecialchars($_POST['contribution_amount'] ?? $editing['contribution_amount'] ?? '') ?>"
               required>
        <small class="form-hint">Each member pays this every cycle.</small>
      </div>

      <div class="form-group">
        <label>Frequency (Days between collections)</label>
        <input type="number" name="frequency_days" min="1"
               value="<?= htmlspecialchars($_POST['frequency_days'] ?? $editing['frequency_days'] ?? '7') ?>"
               required>
        <small class="form-hint">1 = daily &nbsp;·&nbsp; 7 = weekly &nbsp;·&nbsp; 14 = fortnightly &nbsp;·&nbsp; 30 = monthly</small>
      </div>

      <div class="form-group">
        <label>Total Participants (Group Size)</label>
        <input type="number" name="total_participants" min="2"
               value="<?= htmlspecialchars($_POST['total_participants'] ?? $editing['total_participants'] ?? '5') ?>"
               required>
        <small class="form-hint">
          Once this number is reached, the group locks and no new members can join.
          Payout = contribution × participants.
        </small>
      </div>

      <div class="form-group">
        <label>Plan Start Date</label>
        <input type="date" name="plan_start_date"
               value="<?= htmlspecialchars($_POST['plan_start_date'] ?? $editing['plan_start_date'] ?? '') ?>">
        <small class="form-hint">
          The date Position 1 collects. Setting this calculates every member's collection date automatically.
          When you set this AND the group is full, the plan auto-activates and locks for new members.
        </small>
      </div>

      <div class="form-group form-group--checkbox">
        <label class="checkbox-label">
          <input type="checkbox" name="is_active" value="1"
                 <?= (!isset($_POST['is_active']) && ($editing['is_active'] ?? 1)) || isset($_POST['is_active']) ? 'checked' : '' ?>>
          Plan is visible to members (show on Join a Plan page)
        </label>
      </div>

      <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
        <button type="submit" class="btn btn-primary"><?= $editing ? 'Update Plan' : 'Create Plan' ?></button>
        <?php if ($editing): ?><a href="plans.php" class="btn btn-outline">Cancel</a><?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Plans table -->
  <div class="admin-table-panel">
    <h2>All Plans (<?= count($plans) ?>)</h2>
    <div class="table-wrapper">
      <table class="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Amount</th>
            <th>Slots</th>
            <th>Start Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($plans as $p):
            $slots_left = intval($p['total_participants']) - intval($p['slots_filled']);
            $payout     = calculatePayoutAmount($p['contribution_amount'], $p['total_participants']);
            $collected  = getPlanCollectedCount($conn, $p['id']);
            $is_full    = $slots_left <= 0;
          ?>
          <tr>
            <td>
              <strong><?= htmlspecialchars($p['name']) ?></strong>
              <div style="font-size:.78rem;color:var(--gold);margin-top:.2rem;">
                Payout: <?= formatMoney($payout) ?>
                &nbsp;·&nbsp; <?= $collected ?>/<?= $p['total_participants'] ?> collected
              </div>
              <!-- Visual status flow -->
              <div class="status-flow">
                <span class="status-flow__step <?= $p['plan_status']==='open'?'status-flow__step--active':'status-flow__step--done' ?>">Open</span>
                <span class="status-flow__arrow">›</span>
                <span class="status-flow__step <?= $p['plan_status']==='active'?'status-flow__step--active':($p['plan_status']==='completed'?'status-flow__step--done':'status-flow__step--future') ?>">Active</span>
                <span class="status-flow__arrow">›</span>
                <span class="status-flow__step <?= $p['plan_status']==='completed'?'status-flow__step--done':'status-flow__step--future' ?>">Completed</span>
              </div>
            </td>

            <td><?= formatMoney($p['contribution_amount']) ?><br>
                <small style="color:var(--gray-text)"><?= formatFrequency($p['frequency_days']) ?></small></td>

            <td>
              <strong><?= $p['slots_filled'] ?>/<?= $p['total_participants'] ?></strong>
              <div style="font-size:.75rem;color:<?= $is_full?'var(--error)':'var(--gray-text)' ?>">
                <?= $is_full ? '🔒 Full' : $slots_left.' left' ?>
              </div>
            </td>

            <td style="font-size:.82rem;">
              <?= $p['plan_start_date'] ? date('M j, Y', strtotime($p['plan_start_date'])) : '<span style="color:var(--error)">Not set</span>' ?>
            </td>

            <td>
              <span class="status-badge status-badge--<?= $p['plan_status']==='active'?'active':($p['plan_status']==='completed'?'completed':'pending') ?>">
                <?= ucfirst($p['plan_status']) ?>
              </span>
              <?php if (!$p['is_active']): ?>
                <div style="font-size:.72rem;color:var(--error);margin-top:.2rem;">Hidden from members</div>
              <?php endif; ?>
            </td>

            <td>
              <div style="display:flex;gap:.35rem;flex-wrap:wrap;">
                <a href="plans.php?edit=<?= $p['id'] ?>"     class="btn-action btn-action--edit">Edit</a>
                <a href="rotation.php?plan=<?= $p['id'] ?>"  class="btn-action btn-action--view">Rotation</a>

                <?php if ($p['plan_status'] === 'open'): ?>
                  <a href="plans.php?setstatus=active&plan=<?= $p['id'] ?>"
                     class="btn-action btn-action--edit" style="background:#EDF7F1;color:var(--success);"
                     onclick="return confirm('Start this plan now? No new members can join after this.')">
                     ▶ Start
                  </a>
                <?php elseif ($p['plan_status'] === 'active'): ?>
                  <span class="btn-action" style="background:var(--gray-light);color:var(--gray-text);cursor:default;">Running</span>
                <?php endif; ?>

                <a href="plans.php?delete=<?= $p['id'] ?>" class="btn-action btn-action--delete"
                   onclick="return confirm('Delete this plan? This cannot be undone.')">Delete</a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>

          <?php if (empty($plans)): ?>
            <tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--gray-text)">No plans yet. Create your first plan on the left.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</div></main>
</body>
</html>
